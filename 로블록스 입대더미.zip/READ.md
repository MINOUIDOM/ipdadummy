뉴비뉴비뉴비짱 클릭->HumanoidRootPart 클릭 ProximityRootPart
 열고 안에 스크립트창 여세요
if	 plr:IsInGroup(0) and plr.TeamColor == BrickColor.new("특정 팀만 버튼 누를수있음") then 
여기서 plr:IsInGroup(0) 이부분 있죠? 여기서 0을 님들 그룹
숫자로 바꾸세요그다음에 BrickColor.new(">") 여기서 특정 팀만
버튼 눌러지게 팀 색상을 적으세요(부대겜을은 시민색깔 적어야하는거
알쥬?) (대문자 소문자 틀리지않게)
그다음에 plr.TeamColore = BrickColor.new("바꿀팀 색갈") 에서 바꿀팀 색갈을 지운담에
바꿀팀 색상 적으3
chat:Chat(script.Parent.Parent.Parent.Parent.Head,plr.Name.. "거부당하면 npc 가 하는말 적으 3")
거부당하면 npc 가 하는말 적으 3 여기서 님들이 그룹가입 안돼있으면
npc 가 할말 예:(그룹가입을 하고 입대하거라 어리석은 닝겐 ㅋ)
이따구로 적으 삼삼 그리고 버튼 글씨 바꿀려면 ProximityPrompt
이름을 버튼 이름으로 바꾸셈
